$(document).ready(function () {
	$("#fb-ico").hover(function () {
		$("#fb").toggle(500);
	});

	$("#yt-ico").hover(function () {
		$("#yt").toggle(500);
	});

	$("#ig-ico").hover(function () {
		$("#ig").toggle(500);
	});

	$("#sch-ico").hover(function () {
		$("#sc").toggle(500);
	});
});
