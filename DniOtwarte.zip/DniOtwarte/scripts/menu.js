$(document).ready(function () {
	$("#menu-ham").click(function () {
		$("#menu").toggle(800);
	});

	$("#typewriter").click(function () {
		$("#menu").toggle(800);
	});
});
